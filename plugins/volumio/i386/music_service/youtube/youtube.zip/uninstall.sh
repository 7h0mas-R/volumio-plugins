#!/bin/bash
cd ..
sudo rm -rf ./cris-volumio

echo "pluginuninstallend"