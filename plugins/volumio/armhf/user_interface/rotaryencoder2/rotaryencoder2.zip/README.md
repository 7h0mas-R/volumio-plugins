# Rotary Encoder II #
For details see the man page:

*not yet published*

Draft [here](https://github.com/volumio/docs/blob/master/docs/06_Plugins_User_Manuals/01_rotaryencoder2/00_Rotary_Encoder_II.md)